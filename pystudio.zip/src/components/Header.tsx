import React, { useState } from 'react';
import { 
  Terminal, 
  Users, 
  Copy, 
  MessageSquare, 
  Box, 
  Play, 
  Loader2, 
  AlertCircle,
  Code2,
  Columns,
  SquareTerminal,
  CheckCheck,
  ArrowRight,
  Hand,
  Home,
  LogOut,
  Square
} from 'lucide-react';
import { UserPresence } from '../types';
import { PyodideStatus } from '../services/pyodide';

export type WorkspaceViewMode = 'split' | 'editor' | 'terminal';

interface HeaderProps {
  pyStatus: PyodideStatus;
  roomId: string;
  roomInputValue: string;
  onRoomInputChange: (val: string) => void;
  onJoinRoom: () => void;
  onCopyRoomLink: () => void;
  collaborators: Record<string, UserPresence>;
  currentUserId: string;
  isChatOpen: boolean;
  unreadChatCount: number;
  onToggleChat: () => void;
  onOpenPipModal: () => void;
  isRunning: boolean;
  onRunCode: () => void;
  onForceStop?: () => void;
  viewMode: WorkspaceViewMode;
  onViewModeChange: (mode: WorkspaceViewMode) => void;
  roomPackageCount?: number;
  onRaiseHand: () => void;
  handRaiseCooldown: number;
  onLeaveRoom?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  pyStatus,
  roomId,
  roomInputValue,
  onRoomInputChange,
  onJoinRoom,
  onCopyRoomLink,
  collaborators,
  currentUserId,
  isChatOpen,
  unreadChatCount,
  onToggleChat,
  onOpenPipModal,
  isRunning,
  onRunCode,
  onForceStop,
  viewMode,
  onViewModeChange,
  roomPackageCount = 0,
  onRaiseHand,
  handRaiseCooldown,
  onLeaveRoom
}) => {
  const [copied, setCopied] = useState(false);
  const usersArray: UserPresence[] = Object.values(collaborators);

  const handleCopy = () => {
    onCopyRoomLink();
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleRoomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (roomInputValue.trim()) {
      onJoinRoom();
    }
  };

  const isDifferentRoom = roomInputValue.trim() !== '' && roomInputValue.trim() !== roomId;

  return (
    <header className="bg-slate-900/95 backdrop-blur border-b border-slate-800 shadow-md shrink-0 w-full select-none z-30 relative overflow-x-auto no-scrollbar overscroll-x-contain">
      
      {/* Fully inline toolbar layout - No floating windows or modals */}
      <div className="px-2.5 sm:px-3 py-1.5 sm:py-2 flex items-center justify-between gap-2.5 sm:gap-4 min-w-max w-full">

        {/* SECTION 1: Brand Logo & WASM Engine Status & Menu Navigation */}
        <div className="flex items-center space-x-1.5 sm:space-x-2 shrink-0">
          {onLeaveRoom && (
            <button
              type="button"
              onClick={onLeaveRoom}
              title="Return to Main Menu / Choose another room"
              className="p-1 sm:p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-amber-300 border border-slate-700/80 transition cursor-pointer flex items-center gap-1 text-xs shrink-0"
            >
              <Home className="w-3.5 h-3.5" />
              <span className="text-[11px] hidden md:inline">Menu</span>
            </button>
          )}

          <div className="bg-amber-500 text-slate-950 p-1 sm:p-1.5 rounded-lg font-bold flex items-center justify-center shadow-sm shadow-amber-500/20 shrink-0">
            <Terminal className="w-3.5 h-3.5 sm:w-4 sm:h-4 stroke-[2.5]" />
          </div>
          
          <div className="flex items-center gap-1.5 shrink-0">
            <h1 className="font-bold text-xs sm:text-sm md:text-base leading-none text-slate-100 flex items-center gap-1 shrink-0">
              PyStudio
            </h1>

            {/* Python WASM Engine Indicator */}
            {pyStatus === 'loading' && (
              <span 
                title="Loading Python 3.11 WebAssembly kernel..." 
                className="text-[9px] sm:text-[10px] bg-amber-500/15 text-amber-400 px-1.5 py-0.5 rounded-full border border-amber-500/30 flex items-center gap-1 shrink-0"
              >
                <Loader2 className="w-2.5 h-2.5 animate-spin" />
                <span className="font-mono">Python 3.11</span>
              </span>
            )}
            {pyStatus === 'ready' && (
              <span 
                title="Python 3.11 WASM ready in browser" 
                className="text-[9px] sm:text-[10px] bg-emerald-500/15 text-emerald-400 px-1.5 py-0.5 rounded-full border border-emerald-500/30 flex items-center gap-1 shrink-0"
              >
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span className="font-mono">Python 3.11</span>
              </span>
            )}
            {pyStatus === 'failed' && (
              <span 
                title="WASM initialization error" 
                className="text-[9px] sm:text-[10px] bg-rose-500/15 text-rose-400 px-1.5 py-0.5 rounded-full border border-rose-500/30 flex items-center gap-1 shrink-0"
              >
                <AlertCircle className="w-2.5 h-2.5" />
                <span>Error</span>
              </span>
            )}
          </div>
        </div>

        {/* SECTION 2: Direct Inline Room Controls (No floating popup) */}
        <div className="flex items-center space-x-1.5 sm:space-x-2 shrink-0 bg-slate-950/70 border border-slate-800/90 rounded-lg p-1">
          <form onSubmit={handleRoomSubmit} className="flex items-center gap-1 shrink-0">
            <div className="flex items-center gap-1 bg-slate-900 border border-slate-700/80 rounded-md px-2 py-1 focus-within:border-amber-500 transition">
              <Users className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span className="text-slate-500 font-mono text-xs">#</span>
              <input
                type="text"
                value={roomInputValue}
                onChange={(e) => onRoomInputChange(e.target.value)}
                placeholder="room-id"
                title="Type room name and press Enter to join"
                className="bg-transparent text-amber-300 font-mono text-xs font-semibold focus:outline-none w-24 sm:w-28 md:w-32 placeholder-slate-600"
              />
            </div>

            {/* Join / Switch Button if typed room differs from active room */}
            {isDifferentRoom && (
              <button
                type="submit"
                title="Join room"
                className="bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 px-2 py-1 rounded-md text-xs font-bold transition cursor-pointer flex items-center gap-1 shrink-0"
              >
                <span>Join</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            )}

            {/* Direct 1-Tap Copy Link Button */}
            <button
              type="button"
              onClick={handleCopy}
              title="Copy room invite link"
              className="bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 border border-slate-700/80 px-2 py-1 rounded-md text-xs font-medium transition cursor-pointer flex items-center gap-1 shrink-0"
            >
              {copied ? (
                <>
                  <CheckCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-[11px] text-emerald-400 font-semibold">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-slate-300" />
                  <span className="text-[11px] hidden xs:inline">Copy</span>
                </>
              )}
            </button>
          </form>

          {/* Active Collaborators Avatars & Online Counter */}
          <div className="flex items-center space-x-1 pl-1.5 border-l border-slate-800 shrink-0">
            <div className="flex -space-x-1.5 overflow-hidden shrink-0">
              {usersArray.slice(0, 3).map((user) => {
                const isMe = user.id === currentUserId;
                return (
                  <div
                    key={user.id}
                    style={{ backgroundColor: user.color || '#3b82f6' }}
                    title={`${user.name || user.id}${isMe ? ' (You)' : ''}`}
                    className="w-5 h-5 sm:w-6 sm:h-6 rounded-full flex items-center justify-center text-[9px] sm:text-[10px] font-bold text-white border border-slate-900 uppercase shrink-0 select-none shadow"
                  >
                    {String(user.name || user.id || '?').substring(0, 2)}
                  </div>
                );
              })}
              {usersArray.length > 3 && (
                <div className="w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-slate-700 flex items-center justify-center text-[8px] sm:text-[9px] font-bold text-slate-200 border border-slate-900 shrink-0">
                  +{usersArray.length - 3}
                </div>
              )}
            </div>
            <span className="text-[10px] text-slate-400 font-mono hidden sm:inline pl-1">
              {usersArray.length} online
            </span>
          </div>
        </div>

        {/* SECTION 3: View Mode & Action Tools */}
        <div className="flex items-center space-x-1.5 sm:space-x-2 shrink-0">
          
          {/* View Mode Switcher (Editor / Split / Terminal) */}
          <div className="flex items-center bg-slate-950/80 p-0.5 rounded-lg border border-slate-800 shrink-0">
            <button
              onClick={() => onViewModeChange('editor')}
              title="Code Editor Only"
              className={`px-2 py-1 rounded text-[11px] font-medium transition flex items-center gap-1 cursor-pointer shrink-0 ${
                viewMode === 'editor' 
                  ? 'bg-slate-800 text-amber-400 shadow-sm border border-slate-700' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Code2 className="w-3.5 h-3.5 shrink-0" />
              <span className="text-[11px]">Editor</span>
            </button>
            <button
              onClick={() => onViewModeChange('split')}
              title="Split Code & Terminal"
              className={`px-2 py-1 rounded text-[11px] font-medium transition flex items-center gap-1 cursor-pointer shrink-0 ${
                viewMode === 'split' 
                  ? 'bg-slate-800 text-amber-400 shadow-sm border border-slate-700' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Columns className="w-3.5 h-3.5 shrink-0" />
              <span className="text-[11px]">Split</span>
            </button>
            <button
              onClick={() => onViewModeChange('terminal')}
              title="Interactive Terminal Full View"
              className={`px-2 py-1 rounded text-[11px] font-medium transition flex items-center gap-1 cursor-pointer shrink-0 ${
                viewMode === 'terminal' 
                  ? 'bg-slate-800 text-amber-400 shadow-sm border border-slate-700' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <SquareTerminal className="w-3.5 h-3.5 shrink-0" />
              <span className="text-[11px]">Terminal</span>
            </button>
          </div>

          {/* Raise Hand Button (Request others to pause/stop for editing) */}
          <button
            onClick={onRaiseHand}
            disabled={handRaiseCooldown > 0}
            title={
              handRaiseCooldown > 0 
                ? `Raise Hand cooldown active (${handRaiseCooldown}s remaining)` 
                : "Raise Hand: Request others to stop running/waiting so you can edit code (20s cooldown)"
            }
            className={`px-2 py-1 sm:px-2.5 sm:py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 cursor-pointer shrink-0 border ${
              handRaiseCooldown > 0
                ? 'bg-slate-800/80 text-slate-500 border-slate-800 cursor-not-allowed'
                : 'bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border-amber-500/40 hover:border-amber-500 active:scale-95 shadow-sm shadow-amber-500/10'
            }`}
          >
            <Hand className={`w-3.5 h-3.5 shrink-0 ${handRaiseCooldown === 0 ? 'text-amber-400 animate-bounce' : 'text-slate-500'}`} />
            <span className="text-[11px]">
              {handRaiseCooldown > 0 ? `Wait ${handRaiseCooldown}s` : 'Raise Hand'}
            </span>
          </button>

          {/* Pip Package Manager */}
          <button
            onClick={onOpenPipModal}
            title={roomPackageCount > 0 ? `${roomPackageCount} room packages active (preserved in room)` : "Install Python Packages (Micropip)"}
            className="bg-slate-800 hover:bg-slate-700 text-amber-400 border border-slate-700 px-2 py-1 sm:px-2.5 sm:py-1.5 rounded-lg text-xs font-medium transition flex items-center gap-1 cursor-pointer shrink-0 relative"
          >
            <Box className="w-3.5 h-3.5 shrink-0" />
            <span className="text-[11px]">Pip</span>
            {roomPackageCount > 0 && (
              <span className="ml-0.5 bg-amber-500/20 text-amber-300 text-[10px] font-mono font-bold px-1.5 py-0.2 rounded-full border border-amber-500/30">
                {roomPackageCount}
              </span>
            )}
          </button>

          {/* Chat Toggle Button */}
          <button
            onClick={onToggleChat}
            title="Collaborative Room Chat"
            className={`relative bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 px-2 py-1 sm:px-2.5 sm:py-1.5 rounded-lg text-xs font-medium transition flex items-center gap-1 cursor-pointer shrink-0 ${
              isChatOpen ? 'border-amber-500/50 bg-slate-800 text-amber-300' : ''
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="text-[11px]">Chat</span>
            {unreadChatCount > 0 && !isChatOpen && (
              <span className="absolute -top-1 -right-1 bg-amber-500 text-slate-950 text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center border border-slate-900 shrink-0">
                {unreadChatCount}
              </span>
            )}
          </button>

          {/* Run / Stop Code Button */}
          {isRunning ? (
            <button
              type="button"
              onClick={onForceStop}
              title="Stop Python Execution immediately (1-click Stop)"
              className="bg-rose-600 hover:bg-rose-500 active:scale-95 text-white font-bold px-3 sm:px-3.5 py-1 sm:py-1.5 rounded-lg text-xs transition flex items-center gap-1.5 shadow-md shadow-rose-950/40 cursor-pointer shrink-0 animate-pulse"
            >
              <Square className="w-3.5 h-3.5 fill-current shrink-0" />
              <span className="text-xs font-bold">Stop</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={onRunCode}
              disabled={pyStatus === 'loading'}
              title="Run Python Code (Ctrl+Enter)"
              className="bg-emerald-600 hover:bg-emerald-500 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold px-3 sm:px-3.5 py-1 sm:py-1.5 rounded-lg text-xs transition flex items-center gap-1.5 shadow-md shadow-emerald-950/40 cursor-pointer shrink-0"
            >
              <Play className="w-3.5 h-3.5 fill-current shrink-0" />
              <span className="text-xs font-bold">Run</span>
            </button>
          )}
        </div>

      </div>
    </header>
  );
};
