import React, { useState } from 'react';
import { 
  Terminal, 
  Users, 
  Sparkles, 
  ArrowRight, 
  Cpu, 
  Box, 
  Zap, 
  ShieldCheck,
  Hash,
  User,
  Palette
} from 'lucide-react';
import { USER_COLORS } from '../constants/python';

interface MainMenuProps {
  initialRoomNumber?: string;
  userName: string;
  userColor: string;
  onUserNameChange: (name: string) => void;
  onUserColorChange: (color: string) => void;
  onJoinRoom: (roomId: string) => void;
}

const FEATURED_ROOMS = [
  { id: '101', label: 'Room #101', desc: 'Python Beginners & Sandbox' },
  { id: '102', label: 'Room #102', desc: 'Data Science & Algorithms' },
  { id: 'python-lab', label: 'Python Lab', desc: 'General Collaboration' },
  { id: 'live-collab', label: 'Live Collab', desc: 'Interactive Terminal & Pip' }
];

export const MainMenu: React.FC<MainMenuProps> = ({
  initialRoomNumber = '',
  userName,
  userColor,
  onUserNameChange,
  onUserColorChange,
  onJoinRoom
}) => {
  const [roomNumber, setRoomNumber] = useState(initialRoomNumber || '101');
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanRoom = roomNumber.trim();
    if (!cleanRoom) {
      setErrorMsg('Please enter a room number or name to continue.');
      return;
    }
    setErrorMsg('');
    onJoinRoom(cleanRoom);
  };

  const handleSelectFeaturedRoom = (id: string) => {
    setRoomNumber(id);
    onJoinRoom(id);
  };

  return (
    <div className="min-h-screen bg-[#06080e] text-slate-100 flex flex-col justify-between p-4 sm:p-6 lg:p-8 relative select-none overflow-y-auto">
      {/* Background Matrix/Grid Aesthetic */}
      <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:28px_28px] opacity-20 pointer-events-none" />

      {/* Ambient Lighting Orbs */}
      <div className="absolute w-96 h-96 bg-amber-500/10 rounded-full blur-[120px] pointer-events-none -top-20 -left-20 animate-pulse" />
      <div className="absolute w-96 h-96 bg-emerald-500/10 rounded-full blur-[130px] pointer-events-none -bottom-20 -right-20 animate-pulse delay-1000" />

      {/* Top Navbar Brand */}
      <header className="relative z-10 max-w-5xl mx-auto w-full flex items-center justify-between py-2">
        <div className="flex items-center space-x-2.5">
          <div className="bg-amber-500 text-slate-950 p-2 rounded-xl font-black flex items-center justify-center shadow-lg shadow-amber-500/20">
            <Terminal className="w-5 h-5 stroke-[2.5]" />
          </div>
          <div>
            <h1 className="font-bold text-lg sm:text-xl tracking-tight text-white flex items-center gap-1.5">
              PyStudio
            </h1>
            <span className="text-[10px] text-amber-400 font-mono font-medium block">
              Python 3.11 WASM • Realtime Collaborative IDE
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="hidden sm:inline-flex items-center gap-1.5 text-xs bg-slate-900 border border-slate-800 text-emerald-400 px-3 py-1 rounded-full font-mono">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            CPython 3.11 Runtime
          </span>
        </div>
      </header>

      {/* Main Interactive Hub */}
      <main className="relative z-10 max-w-xl mx-auto w-full my-auto py-6 sm:py-8 space-y-6">
        
        {/* Welcome Card Container */}
        <div className="bg-slate-900/90 border border-slate-800/90 rounded-3xl p-5 sm:p-7 shadow-2xl backdrop-blur-xl space-y-5">
          
          <div className="text-center space-y-1.5">
            <h2 className="text-xl sm:text-2xl font-bold text-slate-100 tracking-tight">
              Join or Create a Room
            </h2>
            <p className="text-xs sm:text-sm text-slate-400">
              Enter any room number to collaborate with peers in real-time with full Python terminal support.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            
            {/* Room Number Input */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <Hash className="w-3.5 h-3.5 text-amber-400" />
                Room Number or Name:
              </label>
              <div className="relative flex items-center">
                <span className="absolute left-3.5 text-slate-500 font-mono text-sm font-bold">#</span>
                <input
                  type="text"
                  value={roomNumber}
                  onChange={(e) => {
                    setRoomNumber(e.target.value);
                    if (errorMsg) setErrorMsg('');
                  }}
                  placeholder="e.g. 101, 202, algorithms, team-live"
                  autoFocus
                  className="w-full bg-slate-950 border border-slate-700/90 focus:border-amber-500 rounded-xl pl-8 pr-4 py-2.5 text-sm sm:text-base font-mono font-bold text-amber-300 placeholder:text-slate-600 focus:outline-none transition shadow-inner"
                />
              </div>
              {errorMsg && (
                <p className="text-rose-400 text-xs mt-1 font-medium">{errorMsg}</p>
              )}
            </div>

            {/* User Profile Customization */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-amber-400" />
                  Your Display Name:
                </label>
                <input
                  type="text"
                  value={userName}
                  onChange={(e) => onUserNameChange(e.target.value)}
                  placeholder="e.g. Developer"
                  maxLength={24}
                  className="w-full bg-slate-950 border border-slate-700/90 focus:border-amber-500 rounded-xl px-3 py-2 text-xs sm:text-sm text-slate-200 placeholder:text-slate-600 focus:outline-none transition"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <Palette className="w-3.5 h-3.5 text-amber-400" />
                  Cursor & Badge Color:
                </label>
                <div className="flex items-center gap-2 bg-slate-950 border border-slate-700/90 rounded-xl px-2.5 py-1.5">
                  {USER_COLORS.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => onUserColorChange(c)}
                      style={{ backgroundColor: c }}
                      className={`w-5 h-5 rounded-full transition-transform cursor-pointer shrink-0 ${
                        userColor === c ? 'scale-125 ring-2 ring-white shadow-md' : 'opacity-70 hover:opacity-100 hover:scale-110'
                      }`}
                      title={c}
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Primary Action Button - MUST HAVE EXACT TEXT "Join/create" */}
            <button
              type="submit"
              className="w-full bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-bold py-3 px-4 rounded-xl text-sm sm:text-base transition-all transform active:scale-[0.99] flex items-center justify-center gap-2 shadow-lg shadow-amber-500/25 cursor-pointer mt-2"
            >
              <span>Join/create</span>
              <ArrowRight className="w-4 h-4 stroke-[2.5]" />
            </button>

          </form>

          {/* Quick Preset Rooms */}
          <div className="pt-2 border-t border-slate-800/80 space-y-2">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Suggested Rooms:
            </span>
            <div className="grid grid-cols-2 gap-2">
              {FEATURED_ROOMS.map((room) => (
                <button
                  key={room.id}
                  type="button"
                  onClick={() => handleSelectFeaturedRoom(room.id)}
                  className="bg-slate-950/80 hover:bg-slate-800/90 border border-slate-800 hover:border-amber-500/40 rounded-xl p-2.5 text-left transition cursor-pointer group flex flex-col justify-between"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-xs text-amber-400 group-hover:text-amber-300">
                      #{room.id}
                    </span>
                    <Users className="w-3 h-3 text-slate-500 group-hover:text-amber-400 transition-colors" />
                  </div>
                  <span className="text-[10px] text-slate-400 mt-1 line-clamp-1">
                    {room.desc}
                  </span>
                </button>
              ))}
            </div>
          </div>

        </div>

        {/* Feature Highlights Grid */}
        <div className="grid grid-cols-3 gap-2.5 text-center text-xs text-slate-400 font-mono">
          <div className="bg-slate-900/60 border border-slate-800/60 rounded-2xl p-2.5 space-y-1">
            <Cpu className="w-4 h-4 text-emerald-400 mx-auto" />
            <span className="block font-semibold text-slate-300 text-[11px]">WASM Kernel</span>
            <span className="text-[10px] text-slate-500">CPython 3.11</span>
          </div>

          <div className="bg-slate-900/60 border border-slate-800/60 rounded-2xl p-2.5 space-y-1">
            <Users className="w-4 h-4 text-amber-400 mx-auto" />
            <span className="block font-semibold text-slate-300 text-[11px]">Live Presence</span>
            <span className="text-[10px] text-slate-500">Multiplayer Cursors</span>
          </div>

          <div className="bg-slate-900/60 border border-slate-800/60 rounded-2xl p-2.5 space-y-1">
            <Box className="w-4 h-4 text-sky-400 mx-auto" />
            <span className="block font-semibold text-slate-300 text-[11px]">Room Pip</span>
            <span className="text-[10px] text-slate-500">Synced Packages</span>
          </div>
        </div>

      </main>

      {/* Footer */}
      <footer className="relative z-10 text-center text-[11px] text-slate-600 font-mono py-2">
        PyStudio Collaborative Python IDE • Zero-Server WASM Execution
      </footer>
    </div>
  );
};
